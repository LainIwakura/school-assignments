package uwindsor.cs256;
public class CCC {
    aaa a ;
    public CCC(aaa a) {
        this.a=a ;
    }
}
