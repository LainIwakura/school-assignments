package uwindsor.cs256;
public class BBB {
    aaa aaaInstance ; // an instance of aaa
    int aaaNum=0 ;
    public BBB() {
    }
}
