package uwindsor.cs256;
public class aaa {
    public aaa() {
    }
}
